# ConnectPH Network Business - XAMPP Setup Instructions

## Prerequisites
- Download and install XAMPP from https://www.apachefriends.org/

## Setup Steps

### 1. File Placement
1. Copy all project files to your XAMPP `htdocs` folder:
   - Windows: `C:\xampp\htdocs\connectph\`
   - Mac/Linux: `/Applications/XAMPP/htdocs/connectph/`

### 2. Start XAMPP Services
1. Open XAMPP Control Panel
2. Start **Apache** service
3. Start **MySQL** service

### 3. Database Setup
1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Click "New" to create a database
3. Name it: `networkdb`
4. Click "Create"
5. Select the `networkdb` database
6. Click "Import" tab
7. Choose the `database_setup.sql` file
8. Click "Go" to execute

### 4. Test the Website
1. Open your browser
2. Go to: `http://localhost/connectph/`
3. Navigate through the site and test forms

### 5. Admin Access
- View customers: `http://localhost/connectph/view_customers.php`
- View inquiries: `http://localhost/connectph/view_inquiries.php`

## File Structure
\`\`\`
htdocs/connectph/
├── index.html
├── plans.html
├── customer-form.html
├── inquiries.html
├── support.html
├── styles.css
├── db_connect.php
├── process_customer.php
├── process_inquiry.php
├── view_customers.php
├── view_inquiries.php
├── database_setup.sql
└── XAMPP_SETUP_INSTRUCTIONS.md
\`\`\`

## Troubleshooting
- If forms don't work, check that Apache and MySQL are running
- If database connection fails, verify the database name is `networkdb`
- For permission issues, ensure XAMPP has proper file access rights
